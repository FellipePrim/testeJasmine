# tdd-jasmine
Repositório de testes automatizados com Jasmine Framework 
<p>Projeto realizado no curso <b>Técnico de Desenvolvimento de Sistemas - Senai</b>😊</p>

<h2>Atividades de testes com JavaScript</h2>
<br>
<h3>Estrutura das pastas</h3>
<img src="https://user-images.githubusercontent.com/92833379/158917280-cd6abdd5-63c4-4faf-b378-b5a23023fe11.png">


<h3>Tecnologias utilizadas</h3>

<ul>
  <li>JavaScript</li>
  <li>Jasmine</li>
</ul>


<h2>screen</h2>

<h4>TDD</h4>

![image](https://user-images.githubusercontent.com/92833379/158916795-14ca770f-4897-44ed-aff0-727d84c63e9e.png)
<br>
![image](https://user-images.githubusercontent.com/92833379/158916827-7ee5f34a-4b29-4519-a338-154073479c5c.png)
<br>

<h4>Arquivos de função</h4>

![image](https://user-images.githubusercontent.com/92833379/158917058-df2bd8d1-d5de-465e-baa1-2636a627e8cb.png)
<br>
![image](https://user-images.githubusercontent.com/92833379/158917078-e1bc863c-f96c-4cad-9099-380b712e91bb.png)

