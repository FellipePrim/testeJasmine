function hello(){
    return 'Hello World!';
}
module.exports = hello;